#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include "item_mec.h"

struct item_mec{
    int codigo_ies;
    char nome_ies[150];
    char categoria_administrativa[100];
    char organizacao_academica[100];
    long codigo_curso;
    char nome_curso[150];
    char grau[50];
    char area_ocde[150];
    char modalidade[50];
    char situacao_curso[50];
    int qt_vagas_autorizadas;
    int carga_horaria;
    int codigo_area_ocde_cine;
    char area_ocde_cine[150];
    char codigo_municipio[30];
    char municipio[100];
    char uf[5];
    char regiao[50];
    double calculated_similarity;
    char *linha_original;
};

ITEM_MEC *item_mec_criar(void) {
    ITEM_MEC *it = (ITEM_MEC*) malloc(sizeof(ITEM_MEC));
    if (it == NULL) return NULL;

    // Inicialização explícita de todos os campos
    it->codigo_ies = 0;
    it->nome_ies[0] = '\0';
    it->categoria_administrativa[0] = '\0';
    it->organizacao_academica[0] = '\0';
    it->codigo_curso = 0;
    it->nome_curso[0] = '\0';
    it->grau[0] = '\0';
    it->area_ocde[0] = '\0';
    it->modalidade[0] = '\0';
    it->situacao_curso[0] = '\0';
    it->qt_vagas_autorizadas = 0;
    it->carga_horaria = 0;
    it->codigo_area_ocde_cine = 0;
    it->area_ocde_cine[0] = '\0';
    it->codigo_municipio[0] = '\0';
    it->municipio[0] = '\0';
    it->uf[0] = '\0';
    it->regiao[0] = '\0';
    it->calculated_similarity = 0;
    it->linha_original = NULL;

    return it;
}

void item_mec_apagar(ITEM_MEC **item){
    if ( item == NULL || *item == NULL ) return;
    free((*item)->linha_original);
    free(*item);
    *item = NULL;
}

void item_mec_imprimir_csv(ITEM_MEC *item, FILE *saida) {
    if (item == NULL || saida == NULL) return;

    fprintf(saida, "%s\n", item->linha_original);
}

int item_mec_comparar(ITEM_MEC *item_A, ITEM_MEC *item_B, char *campo) {
    if (item_A == NULL || item_B == NULL || campo == NULL) return 0;

    // Campos inteiros e longs 
    if (strcasecmp(campo, "codigo_ies") == 0) {
        if (item_A->codigo_ies > item_B->codigo_ies) return 1;
        if (item_A->codigo_ies < item_B->codigo_ies) return -1;
        return 0;
    }
    if (strcasecmp(campo, "codigo_curso") == 0) {
        if (item_A->codigo_curso > item_B->codigo_curso) return 1;
        if (item_A->codigo_curso < item_B->codigo_curso) return -1;
        return 0;
    }
    if (strcasecmp(campo, "qt_vagas_autorizadas") == 0) {
        if (item_A->qt_vagas_autorizadas > item_B->qt_vagas_autorizadas) return 1;
        if (item_A->qt_vagas_autorizadas < item_B->qt_vagas_autorizadas) return -1;
        return 0;
    }
    if (strcasecmp(campo, "carga_horaria") == 0) {
        if (item_A->carga_horaria > item_B->carga_horaria) return 1;
        if (item_A->carga_horaria < item_B->carga_horaria) return -1;
        return 0;
    }
    if (strcasecmp(campo, "codigo_area_ocde_cine") == 0) {
        if (item_A->codigo_area_ocde_cine > item_B->codigo_area_ocde_cine) return 1;
        if (item_A->codigo_area_ocde_cine < item_B->codigo_area_ocde_cine) return -1;
        return 0;
    }
    if (strcasecmp(campo, "similarity") == 0 || strcasecmp(campo, "calculated_similarity") == 0 || strcasecmp(campo, "SIM") == 0) {
        if (item_A->calculated_similarity > item_B->calculated_similarity) return 1;
        if (item_A->calculated_similarity < item_B->calculated_similarity) return -1;
        return 0;
    }

    // Campos de texto 
    if (strcasecmp(campo, "nome_ies") == 0) {
        return strcasecmp(item_A->nome_ies, item_B->nome_ies);
    }
    if (strcasecmp(campo, "categoria_administrativa") == 0) {
        return strcasecmp(item_A->categoria_administrativa, item_B->categoria_administrativa);
    }
    if (strcasecmp(campo, "organizacao_academica") == 0) {
        return strcasecmp(item_A->organizacao_academica, item_B->organizacao_academica);
    }
    if (strcasecmp(campo, "nome_curso") == 0) {
        return strcasecmp(item_A->nome_curso, item_B->nome_curso);
    }
    if (strcasecmp(campo, "grau") == 0) {
        return strcasecmp(item_A->grau, item_B->grau);
    }
    if (strcasecmp(campo, "area_ocde") == 0) {
        return strcasecmp(item_A->area_ocde, item_B->area_ocde);
    }
    if (strcasecmp(campo, "modalidade") == 0) {
        return strcasecmp(item_A->modalidade, item_B->modalidade);
    }
    if (strcasecmp(campo, "situacao_curso") == 0) {
        return strcasecmp(item_A->situacao_curso, item_B->situacao_curso);
    }
    if (strcasecmp(campo, "area_ocde_cine") == 0) {
        return strcasecmp(item_A->area_ocde_cine, item_B->area_ocde_cine);
    }
    if (strcasecmp(campo, "codigo_municipio") == 0) {
        return strcasecmp(item_A->codigo_municipio, item_B->codigo_municipio);
    }
    if (strcasecmp(campo, "municipio") == 0) {
        return strcasecmp(item_A->municipio, item_B->municipio);
    }
    if (strcasecmp(campo, "uf") == 0) {
        return strcasecmp(item_A->uf, item_B->uf);
    }
    if (strcasecmp(campo, "regiao") == 0) {
        return strcasecmp(item_A->regiao, item_B->regiao);
    }

    return 0;
}

void extrair_valor_campo_item_mec(ITEM_MEC *item, const char *nome_campo, char *dest, int tamanho_max) {
    if (dest == NULL || tamanho_max <= 0) return;
    
    dest[0] = '\0';
    if (item == NULL || nome_campo == NULL) return;

    // Campos numéricos 
    if (strcasecmp(nome_campo, "codigo_ies") == 0) {
        snprintf(dest, tamanho_max, "%d", item->codigo_ies);
    } else if (strcasecmp(nome_campo, "codigo_curso") == 0) {
        snprintf(dest, tamanho_max, "%ld", item->codigo_curso);
    } else if (strcasecmp(nome_campo, "qt_vagas_autorizadas") == 0) {
        snprintf(dest, tamanho_max, "%d", item->qt_vagas_autorizadas);
    } else if (strcasecmp(nome_campo, "carga_horaria") == 0) {
        snprintf(dest, tamanho_max, "%d", item->carga_horaria);
    } else if (strcasecmp(nome_campo, "codigo_area_ocde_cine") == 0) {
        snprintf(dest, tamanho_max, "%d", item->codigo_area_ocde_cine);
    } 
    // Campos de texto
    else if (strcasecmp(nome_campo, "nome_ies") == 0) {
        snprintf(dest, tamanho_max, "%s", item->nome_ies);
    } else if (strcasecmp(nome_campo, "categoria_administrativa") == 0) {
        snprintf(dest, tamanho_max, "%s", item->categoria_administrativa);
    } else if (strcasecmp(nome_campo, "organizacao_academica") == 0) {
        snprintf(dest, tamanho_max, "%s", item->organizacao_academica);
    } else if (strcasecmp(nome_campo, "nome_curso") == 0) {
        snprintf(dest, tamanho_max, "%s", item->nome_curso);
    } else if (strcasecmp(nome_campo, "grau") == 0) {
        snprintf(dest, tamanho_max, "%s", item->grau);
    } else if (strcasecmp(nome_campo, "area_ocde") == 0) {
        snprintf(dest, tamanho_max, "%s", item->area_ocde);
    } else if (strcasecmp(nome_campo, "modalidade") == 0) {
        snprintf(dest, tamanho_max, "%s", item->modalidade);
    } else if (strcasecmp(nome_campo, "situacao_curso") == 0) {
        snprintf(dest, tamanho_max, "%s", item->situacao_curso);
    } else if (strcasecmp(nome_campo, "area_ocde_cine") == 0) {
        snprintf(dest, tamanho_max, "%s", item->area_ocde_cine);
    } else if (strcasecmp(nome_campo, "codigo_municipio") == 0) {
        snprintf(dest, tamanho_max, "%s", item->codigo_municipio);
    } else if (strcasecmp(nome_campo, "municipio") == 0) {
        snprintf(dest, tamanho_max, "%s", item->municipio);
    } else if (strcasecmp(nome_campo, "uf") == 0) {
        snprintf(dest, tamanho_max, "%s", item->uf);
    } else if (strcasecmp(nome_campo, "regiao") == 0) {
        snprintf(dest, tamanho_max, "%s", item->regiao);
    }
}


// --- GETTERS ---

int item_mec_get_codigo_ies(const ITEM_MEC *item) {
    return item ? item->codigo_ies : 0;
}
const char *item_mec_get_nome_ies(const ITEM_MEC *item) {
    return item ? item->nome_ies : NULL;
}
const char *item_mec_get_categoria_administrativa(const ITEM_MEC *item) {
    return item ? item->categoria_administrativa : NULL;
}
const char *item_mec_get_organizacao_academica(const ITEM_MEC *item) {
    return item ? item->organizacao_academica : NULL;
}
long item_mec_get_codigo_curso(const ITEM_MEC *item) {
    return item ? item->codigo_curso : 0L;
}
const char *item_mec_get_nome_curso(const ITEM_MEC *item) {
    return item ? item->nome_curso : NULL;
}
const char *item_mec_get_grau(const ITEM_MEC *item) {
    return item ? item->grau : NULL;
}
const char *item_mec_get_area_ocde(const ITEM_MEC *item) {
    return item ? item->area_ocde : NULL;
}
const char *item_mec_get_modalidade(const ITEM_MEC *item) {
    return item ? item->modalidade : NULL;
}
const char *item_mec_get_situacao_curso(const ITEM_MEC *item) {
    return item ? item->situacao_curso : NULL;
}
int item_mec_get_qt_vagas_autorizadas(const ITEM_MEC *item) {
    return item ? item->qt_vagas_autorizadas : 0;
}
int item_mec_get_carga_horaria(const ITEM_MEC *item) {
    return item ? item->carga_horaria : 0;
}
int item_mec_get_codigo_area_ocde_cine(const ITEM_MEC *item) {
    return item ? item->codigo_area_ocde_cine : 0;
}
const char *item_mec_get_area_ocde_cine(const ITEM_MEC *item) {
    return item ? item->area_ocde_cine : NULL;
}
const char *item_mec_get_codigo_municipio(const ITEM_MEC *item) {
    return item ? item->codigo_municipio : NULL;
}
const char *item_mec_get_municipio(const ITEM_MEC *item) {
    return item ? item->municipio : NULL;
}
const char *item_mec_get_uf(const ITEM_MEC *item) {
    return item ? item->uf : NULL;
}
const char *item_mec_get_regiao(const ITEM_MEC *item) {
    return item ? item->regiao : NULL;
}

// --- SETTERS ---

void item_mec_set_codigo_ies(ITEM_MEC *item, int codigo_ies) {
    if (item) item->codigo_ies = codigo_ies;
}
void item_mec_set_nome_ies(ITEM_MEC *item, const char *nome_ies) {
    if (item) snprintf(item->nome_ies, sizeof(item->nome_ies), "%s", nome_ies ? nome_ies : "");
}
void item_mec_set_categoria_administrativa(ITEM_MEC *item, const char *categoria_administrativa) {
    if (item) snprintf(item->categoria_administrativa, sizeof(item->categoria_administrativa), "%s", categoria_administrativa ? categoria_administrativa : "");
}
void item_mec_set_organizacao_academica(ITEM_MEC *item, const char *organizacao_academica) {
    if (item) snprintf(item->organizacao_academica, sizeof(item->organizacao_academica), "%s", organizacao_academica ? organizacao_academica : "");
}
void item_mec_set_codigo_curso(ITEM_MEC *item, long codigo_curso) {
    if (item) item->codigo_curso = codigo_curso;
}
void item_mec_set_nome_curso(ITEM_MEC *item, const char *nome_curso) {
    if (item) snprintf(item->nome_curso, sizeof(item->nome_curso), "%s", nome_curso ? nome_curso : "");
}
void item_mec_set_grau(ITEM_MEC *item, const char *grau) {
    if (item) snprintf(item->grau, sizeof(item->grau), "%s", grau ? grau : "");
}
void item_mec_set_area_ocde(ITEM_MEC *item, const char *area_ocde) {
    if (item) snprintf(item->area_ocde, sizeof(item->area_ocde), "%s", area_ocde ? area_ocde : "");
}
void item_mec_set_modalidade(ITEM_MEC *item, const char *modalidade) {
    if (item) snprintf(item->modalidade, sizeof(item->modalidade), "%s", modalidade ? modalidade : "");
}
void item_mec_set_situacao_curso(ITEM_MEC *item, const char *situacao_curso) {
    if (item) snprintf(item->situacao_curso, sizeof(item->situacao_curso), "%s", situacao_curso ? situacao_curso : "");
}
void item_mec_set_qt_vagas_autorizadas(ITEM_MEC *item, int qt_vagas_autorizadas) {
    if (item) item->qt_vagas_autorizadas = qt_vagas_autorizadas;
}
void item_mec_set_carga_horaria(ITEM_MEC *item, int carga_horaria) {
    if (item) item->carga_horaria = carga_horaria;
}
void item_mec_set_codigo_area_ocde_cine(ITEM_MEC *item, int codigo_area_ocde_cine) {
    if (item) item->codigo_area_ocde_cine = codigo_area_ocde_cine;
}
void item_mec_set_area_ocde_cine(ITEM_MEC *item, const char *area_ocde_cine) {
    if (item) snprintf(item->area_ocde_cine, sizeof(item->area_ocde_cine), "%s", area_ocde_cine ? area_ocde_cine : "");
}
void item_mec_set_codigo_municipio(ITEM_MEC *item, const char *codigo_municipio) {
    if (item) snprintf(item->codigo_municipio, sizeof(item->codigo_municipio), "%s", codigo_municipio ? codigo_municipio : "");
}
void item_mec_set_municipio(ITEM_MEC *item, const char *municipio) {
    if (item) snprintf(item->municipio, sizeof(item->municipio), "%s", municipio ? municipio : "");
}
void item_mec_set_uf(ITEM_MEC *item, const char *uf) {
    if (item) snprintf(item->uf, sizeof(item->uf), "%s", uf ? uf : "");
}
void item_mec_set_regiao(ITEM_MEC *item, const char *regiao) {
    if (item) snprintf(item->regiao, sizeof(item->regiao), "%s", regiao ? regiao : "");
}

void item_mec_set_linha(ITEM_MEC *item, const char *linha){
    if (item == NULL) return;
    free(item->linha_original);
    item->linha_original = linha ? strdup(linha) : NULL;
}

void item_mec_set_calculated_similarity(ITEM_MEC *item, double similarity){
    if (item) item->calculated_similarity = similarity;
}