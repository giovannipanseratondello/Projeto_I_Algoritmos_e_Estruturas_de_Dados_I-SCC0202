#include <stdbool.h>
#include <stdio.h>

#ifndef ITEM_MEC_H
#define ITEM_MEC_H

typedef struct item_mec ITEM_MEC;

ITEM_MEC *item_mec_criar(void);
void item_mec_apagar(ITEM_MEC **item);
void item_mec_imprimir_csv(ITEM_MEC *item, FILE *saida);  
int item_mec_comparar(ITEM_MEC *item_A, ITEM_MEC *item_B, char *campo);
void extrair_valor_campo_item_mec(ITEM_MEC *item, const char *nome_campo, char *dest, int tamanho_max);

// Getters
int item_mec_get_codigo_ies(const ITEM_MEC *item);
const char *item_mec_get_nome_ies(const ITEM_MEC *item);
const char *item_mec_get_categoria_administrativa(const ITEM_MEC *item);
const char *item_mec_get_organizacao_academica(const ITEM_MEC *item);
long item_mec_get_codigo_curso(const ITEM_MEC *item);
const char *item_mec_get_nome_curso(const ITEM_MEC *item);
const char *item_mec_get_grau(const ITEM_MEC *item);
const char *item_mec_get_area_ocde(const ITEM_MEC *item);
const char *item_mec_get_modalidade(const ITEM_MEC *item);
const char *item_mec_get_situacao_curso(const ITEM_MEC *item);
int item_mec_get_qt_vagas_autorizadas(const ITEM_MEC *item);
int item_mec_get_carga_horaria(const ITEM_MEC *item);
int item_mec_get_codigo_area_ocde_cine(const ITEM_MEC *item);
const char *item_mec_get_area_ocde_cine(const ITEM_MEC *item);
const char *item_mec_get_codigo_municipio(const ITEM_MEC *item);
const char *item_mec_get_municipio(const ITEM_MEC *item);
const char *item_mec_get_uf(const ITEM_MEC *item);
const char *item_mec_get_regiao(const ITEM_MEC *item);

// Setters
void item_mec_set_codigo_ies(ITEM_MEC *item, int codigo_ies);
void item_mec_set_nome_ies(ITEM_MEC *item, const char *nome_ies);
void item_mec_set_categoria_administrativa(ITEM_MEC *item, const char *categoria_administrativa);
void item_mec_set_organizacao_academica(ITEM_MEC *item, const char *organizacao_academica);
void item_mec_set_codigo_curso(ITEM_MEC *item, long codigo_curso);
void item_mec_set_nome_curso(ITEM_MEC *item, const char *nome_curso);
void item_mec_set_grau(ITEM_MEC *item, const char *grau);
void item_mec_set_area_ocde(ITEM_MEC *item, const char *area_ocde);
void item_mec_set_modalidade(ITEM_MEC *item, const char *modalidade);
void item_mec_set_situacao_curso(ITEM_MEC *item, const char *situacao_curso);
void item_mec_set_qt_vagas_autorizadas(ITEM_MEC *item, int qt_vagas_autorizadas);
void item_mec_set_carga_horaria(ITEM_MEC *item, int carga_horaria);
void item_mec_set_codigo_area_ocde_cine(ITEM_MEC *item, int codigo_area_ocde_cine);
void item_mec_set_area_ocde_cine(ITEM_MEC *item, const char *area_ocde_cine);
void item_mec_set_codigo_municipio(ITEM_MEC *item, const char *codigo_municipio);
void item_mec_set_municipio(ITEM_MEC *item, const char *municipio);
void item_mec_set_uf(ITEM_MEC *item, const char *uf);
void item_mec_set_regiao(ITEM_MEC *item, const char *regiao);
void item_mec_set_linha(ITEM_MEC *item, const char *linha);
void item_mec_set_calculated_similarity(ITEM_MEC *item, double similarity);

#endif