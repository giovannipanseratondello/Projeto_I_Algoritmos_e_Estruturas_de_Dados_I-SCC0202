#ifndef READER_MEC_H
#define READER_MEC_H

#include <stdbool.h>
#include "../Item_MEC/item_mec.h"

// Pula a primeira linha (cabeçalho) do arquivo CSV
void reader_mec_pular_cabecalho(FILE *fp);

// Lê a próxima linha válida do arquivo e retorna um ponteiro para ITEM_MEC
ITEM_MEC* reader_mec_ler_item(FILE *fp);

#endif