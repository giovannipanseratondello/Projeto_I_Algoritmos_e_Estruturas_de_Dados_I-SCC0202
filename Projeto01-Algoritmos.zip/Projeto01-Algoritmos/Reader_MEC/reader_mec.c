#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "reader_mec.h"

void reader_mec_pular_cabecalho(FILE *fp){
    if (fp == NULL) return;
    char buffer[2048];
    fgets(buffer,2048,fp);
}

// Função auxiliar para extrair o próximo campo tratando aspas e vírgulas internas
static char *extrair_proximo_campo(char **ptr) {
    if (ptr == NULL || *ptr == NULL) return (char*) "";

    char *inicio = *ptr;
    char *p_leitura = inicio;
    char *p_escrita = inicio;
    int dentro_de_aspas = 0;

    // Se a linha acabou
    if (*inicio == '\0') {
        *ptr = NULL;
        return (char*) "";
    }

    while (*p_leitura != '\0') {
        if (*p_leitura == '"') {
            dentro_de_aspas = !dentro_de_aspas; // Alterna estado de aspas
        } else if (*p_leitura == ',' && !dentro_de_aspas) {
            *p_escrita = '\0';
            *ptr = p_leitura + 1; // Avança o ponteiro para o próximo campo
            return inicio;
        } else {
            *p_escrita = *p_leitura;
            p_escrita++;
        }
        p_leitura++;
    }

    *p_escrita = '\0';
    *ptr = NULL; // Fim da linha
    return inicio;
}

ITEM_MEC* reader_mec_ler_item(FILE *fp) {
    if (fp == NULL) return NULL;

    char linha[2048]; 

    if (fgets(linha, sizeof(linha), fp) == NULL) {
        return NULL;
    }

    // Ignora linhas vazias
    if (linha[0] == '\0' || linha[0] == '\n' || linha[0] == '\r') {
        return reader_mec_ler_item(fp);
    }

    // Remove quebra de linha (\n ou \r) do final
    linha[strcspn(linha, "\r\n")] = '\0';

    ITEM_MEC *novo = item_mec_criar();
    if (novo == NULL) return NULL;

    long long n = strcspn(linha, "\r\n");
    char salvo = linha[n];
    linha[n] = '\0';
    item_mec_set_linha(novo, linha);
    linha[n] = salvo;

    char *cursor = linha;

    item_mec_set_codigo_ies(novo, atoi(extrair_proximo_campo(&cursor)));
    item_mec_set_nome_ies(novo, extrair_proximo_campo(&cursor));
    item_mec_set_categoria_administrativa(novo, extrair_proximo_campo(&cursor));
    item_mec_set_organizacao_academica(novo, extrair_proximo_campo(&cursor));
    item_mec_set_codigo_curso(novo, atol(extrair_proximo_campo(&cursor)));
    item_mec_set_nome_curso(novo, extrair_proximo_campo(&cursor));
    item_mec_set_grau(novo, extrair_proximo_campo(&cursor));
    item_mec_set_area_ocde(novo, extrair_proximo_campo(&cursor));
    item_mec_set_modalidade(novo, extrair_proximo_campo(&cursor));
    item_mec_set_situacao_curso(novo, extrair_proximo_campo(&cursor));
    item_mec_set_qt_vagas_autorizadas(novo, atoi(extrair_proximo_campo(&cursor)));
    item_mec_set_carga_horaria(novo, atoi(extrair_proximo_campo(&cursor)));
    item_mec_set_codigo_area_ocde_cine(novo, atoi(extrair_proximo_campo(&cursor)));
    item_mec_set_area_ocde_cine(novo, extrair_proximo_campo(&cursor));
    item_mec_set_codigo_municipio(novo, extrair_proximo_campo(&cursor));
    item_mec_set_municipio(novo, extrair_proximo_campo(&cursor));
    item_mec_set_uf(novo, extrair_proximo_campo(&cursor));
    item_mec_set_regiao(novo, extrair_proximo_campo(&cursor));

    return novo;
}