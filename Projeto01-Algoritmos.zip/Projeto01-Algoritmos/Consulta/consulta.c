#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <strings.h>
#include <math.h>
#include "consulta.h"

struct filtro {
    char campo[64];
    char operador[4]; 
    char valor_str[128]; 
    double valor_num; 
};

struct similaridade {
    char campo[64];
    double valor_alvo;
    double tolerancia;
    double peso;
};

struct query {
    FILTRO *filtros[32];
    int qnt_filtos;
   
    SIMILARIDADE *similaridades[32];
    int qtd_sim;

    double accept;

    char order_campo[64];
    char order_tipo[8];
    
    char group_campo1[64];
    char group_campo2[64];
   
    char cross_campo1[64];
    char cross_campo2[64];
};

// --- FUNÇÕES AUXILIARES ---

static char* trim_string(char *str) {
    if (str == NULL) return NULL;
    while (*str != '\0' && (*str == ' ' || *str == '\t' || *str == '\r' || *str == '\n')) {
        str++;
    }
    int len = strlen(str);
    while (len > 0 && (str[len - 1] == ' ' || str[len - 1] == '\t' || str[len - 1] == '\r' || str[len - 1] == '\n')) {
        str[len - 1] = '\0';
        len--;
    }
    return str;
}

// --- CARREGAMENTO E LIBERAÇÃO DA QUERY ---

QUERY *query_carregar(char *arquivo) {
    if (arquivo == NULL) return NULL;

    FILE *fp = fopen(arquivo, "r");
    if (fp == NULL) return NULL;

    QUERY *q = (QUERY*) calloc(1, sizeof(QUERY));
    if (q == NULL) {
        fclose(fp);
        return NULL;
    }

    char linha[256];

    while (fgets(linha, sizeof(linha), fp) != NULL) {
        linha[strcspn(linha, "\r\n")] = '\0';

        char *l = trim_string(linha);
        if (l == NULL || l[0] == '\0' || l[0] == '#') continue;

        char *comando = trim_string(strtok(l, "|"));
        if (comando == NULL) continue;

        if (strcasecmp(comando, "FILTER") == 0) {
            char *p1 = trim_string(strtok(NULL, "|"));
            char *p2 = trim_string(strtok(NULL, "|"));
            char *p3 = trim_string(strtok(NULL, "|"));

            if (p1 && p2 && p3 && q->qnt_filtos < 32) {
                FILTRO *f = (FILTRO*) calloc(1, sizeof(FILTRO));
                if (!f) continue;

                strncpy(f->campo, p1, sizeof(f->campo) - 1);
                strncpy(f->operador, p2, sizeof(f->operador) - 1);
                strncpy(f->valor_str, p3, sizeof(f->valor_str) - 1);
                f->valor_num = atof(f->valor_str);

                q->filtros[q->qnt_filtos++] = f;
            }

        } else if (strcasecmp(comando, "SIM") == 0) {
            char *campo = trim_string(strtok(NULL, "|"));
            char *alvo = trim_string(strtok(NULL, "|"));
            char *tol = trim_string(strtok(NULL, "|"));
            char *peso = trim_string(strtok(NULL, "|"));

            if (campo && alvo && tol && peso && q->qtd_sim < 32) {
                SIMILARIDADE *s = (SIMILARIDADE *) calloc(1, sizeof(SIMILARIDADE));
                if (s) {
                    strncpy(s->campo, campo, sizeof(s->campo) - 1);
                    s->valor_alvo = atof(alvo);
                    s->tolerancia = atof(tol);
                    s->peso = atof(peso);
                    q->similaridades[q->qtd_sim++] = s;
                }
            }

        } else if (strcasecmp(comando, "ACCEPT") == 0) {
            char *val = trim_string(strtok(NULL, "|"));
            if (val) q->accept = atof(val);

        } else if (strcasecmp(comando, "ORDER") == 0) {
            char *campo = trim_string(strtok(NULL, "|"));
            char *tipo = trim_string(strtok(NULL, "|"));

            if (campo) strncpy(q->order_campo, campo, sizeof(q->order_campo) - 1);
            if (tipo) strncpy(q->order_tipo, tipo, sizeof(q->order_tipo) - 1);

        } else if (strcasecmp(comando, "GROUP") == 0) {
            char *g1 = trim_string(strtok(NULL, "|"));
            char *g2 = trim_string(strtok(NULL, "|"));

            if (g1) strncpy(q->group_campo1, g1, sizeof(q->group_campo1) - 1);
            if (g2) strncpy(q->group_campo2, g2, sizeof(q->group_campo2) - 1);

        } else if (strcasecmp(comando, "CROSS") == 0) {
            char *c1 = trim_string(strtok(NULL, "|"));
            char *c2 = trim_string(strtok(NULL, "|"));

            if (c1) strncpy(q->cross_campo1, c1, sizeof(q->cross_campo1) - 1);
            if (c2) strncpy(q->cross_campo2, c2, sizeof(q->cross_campo2) - 1);
        }
    }

    fclose(fp);
    return q;
}

void query_destruir(QUERY **q) {
    if (q == NULL || *q == NULL) return;

    for (int i = 0; i < (*q)->qnt_filtos; i++) {
        if ((*q)->filtros[i] != NULL) {
            free((*q)->filtros[i]);
        }
    }

    for (int i = 0; i < (*q)->qtd_sim; i++) {
        if ((*q)->similaridades[i] != NULL) {
            free((*q)->similaridades[i]);
        }
    }

    free(*q);
    *q = NULL;
}

// --- AVALIAÇÃO DE FILTROS E ITENS ---

bool testar_filtro(FILTRO *f, void *item, void (*extrair_valor_campo)(void *, const char *, char *, int)) {
    if (f == NULL || item == NULL) return false;

    char val_buf[256] = "";
    if (extrair_valor_campo != NULL) {
        extrair_valor_campo(item, f->campo, val_buf, sizeof(val_buf));
    }

    // 1. Tratamento para campos Booleanos
    if (strcasecmp(f->valor_str, "true") == 0 || strcasecmp(f->valor_str, "false") == 0 ||
        strcmp(f->valor_str, "1") == 0 || strcmp(f->valor_str, "0") == 0) {

        bool val_bool = (strcasecmp(val_buf, "true") == 0 || strcmp(val_buf, "1") == 0 || strcasecmp(val_buf, "T") == 0);
        bool alvo_bool = (strcasecmp(f->valor_str, "true") == 0 || strcmp(f->valor_str, "1") == 0 || strcasecmp(f->valor_str, "T") == 0);

        if (strcmp(f->operador, "==") == 0) return val_bool == alvo_bool;
        if (strcmp(f->operador, "!=") == 0) return val_bool != alvo_bool;
    }

    // 2. Operadores Numéricos (<, >, <=, >=) ou campos numéricos
    bool is_num_op = (strcmp(f->operador, ">") == 0 || strcmp(f->operador, "<") == 0 ||
                      strcmp(f->operador, ">=") == 0 || strcmp(f->operador, "<=") == 0);

    char *endptr1 = NULL, *endptr2 = NULL;
    double num_item = strtod(val_buf, &endptr1);
    double num_alvo = strtod(f->valor_str, &endptr2);
    bool val_is_num = (endptr1 != val_buf && *endptr1 == '\0');
    bool alvo_is_num = (endptr2 != f->valor_str && *endptr2 == '\0');

    if (is_num_op || (val_is_num && alvo_is_num)) {
        if (strcmp(f->operador, "==") == 0) return fabs(num_item - num_alvo) < 1e-6;
        if (strcmp(f->operador, "!=") == 0) return fabs(num_item - num_alvo) >= 1e-6;
        if (strcmp(f->operador, ">") == 0)  return num_item > num_alvo;
        if (strcmp(f->operador, "<") == 0)  return num_item < num_alvo;
        if (strcmp(f->operador, ">=") == 0) return num_item >= num_alvo;
        if (strcmp(f->operador, "<=") == 0) return num_item <= num_alvo;
    }

    // 3. Comparação de Texto / String (Exata)
    if (strcmp(f->operador, "==") == 0) {
        return strcasecmp(val_buf, f->valor_str) == 0;
    }
    if (strcmp(f->operador, "!=") == 0) {
        return strcasecmp(val_buf, f->valor_str) != 0;
    }

    return true;
}

bool query_avaliar_item(QUERY *q, void *item,
                        void (*extrair_valor_campo)(void *, const char *, char *, int),
                        double *similaridade) {
    
    if ( similaridade ) *similaridade = 0;
    if (q == NULL || item == NULL) return false;


    for (int i = 0; i < q->qnt_filtos; i++) {
        if (!testar_filtro(q->filtros[i], item, extrair_valor_campo)) {
            return false;
        }
    }

    if (q->qtd_sim == 0) {
        return true;
    }

    double soma_pesos = 0.0;
    double soma_score = 0.0;

    for (int i = 0; i < q->qtd_sim; i++) {
        SIMILARIDADE *s = q->similaridades[i];

        char val_buf[256] = "";
        if (extrair_valor_campo != NULL) {
            extrair_valor_campo(item, s->campo, val_buf, sizeof(val_buf));
        }

        double val_x = atof(val_buf);

        double sim_indiv = 0.0;
        if (s->tolerancia > 0) {
            sim_indiv = 1.0 - (fabs(val_x - s->valor_alvo) / s->tolerancia);
            if (sim_indiv < 0.0) sim_indiv = 0.0;
        }

        soma_score += sim_indiv * s->peso;
        soma_pesos += s->peso;
    }

    double score_final = (soma_pesos > 0) ? (soma_score / soma_pesos) : 0.0;
    if ( similaridade ) *similaridade = score_final;
    return score_final >= q->accept;
}

// --- GETTERS DE PARÂMETROS DA QUERY ---

char* query_obter_order_campo(QUERY *q) {
    if (q == NULL) return (char *)"";
    return q->order_campo;
}

char* query_obter_group_campo1(QUERY *q) {
    if (q == NULL) return (char *)"";
    return q->group_campo1;
}

char* query_obter_group_campo2(QUERY *q) {
    if (q == NULL) return (char *)"";
    return q->group_campo2;
}

char* query_obter_cross_campo1(QUERY *q) {
    if (q == NULL) return (char *)"";
    return q->cross_campo1;
}

char* query_obter_cross_campo2(QUERY *q) {
    if (q == NULL) return (char *)"";
    return q->cross_campo2;
}

bool query_order_desc(QUERY *q) {
    return q != NULL && strncasecmp(q->order_tipo, "DESC", 4) == 0;
}