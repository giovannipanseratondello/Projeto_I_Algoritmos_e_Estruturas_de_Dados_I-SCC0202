#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <strings.h>

#include "Item_Nasa/item_nasa.h"
#include "Reader_Nasa/reader_nasa.h"
#include "Item_MEC/item_mec.h"
#include "Reader_MEC/reader_mec.h"
#include "Consulta/consulta.h"
#include "Lista_Cabeca/lista_cabeca.h"
#include "Lista_Cruz/lista_cruz.h"
#include "Lista_Enc/lista_enc.h"
#include "Lista_Gen/lista_gen.h"
#include "Lista_Ord/lista_ord.h"
#include "Lista_Seq/lista_seq.h"
#include "Pilha/pilha.h"
#include "Fila/fila.h"

// --- ESTRUTURAS DE CONTEXTO ---

typedef struct contexto_busca {
    QUERY *query;
    void *result_structure;
    char *result_type;
    int *matched_records;
    double *insert_ms;
    char *reader_name;
    void (*extrair_valor_campo)(void *, const char *, char *, int);
    int (*comparar_item)(void *, void *, char *);
    void (*definir_similaridade) (void*,double);
} ContextoBusca;

typedef struct contexto_escrita{
    FILE *saida;
    int top_k;
    int registros_escritos;
    void (*imprimir_item_csv)(void*, FILE*);
    const char *cabecalho;
} ContextoEscrita;

// --- DECLARAÇÃO DE FUNÇÕES (PROTÓTIPOS) ---

// Função para formatar e gravar um item individual no CSV respeitando o limite top_k
void gravar_item_csv(void *item, void *ctx_void);

// Aloca e inicializa dinamicamente a estrutura de dados especificada pelo nome
void* criar_estrutura(char *tipo);

// Libera a memória da estrutura de dados e de seus itens contidos
void apagar_estutura(char *tipo, void **estrutura, void liberar_item(void **item));

// Lê o arquivo CSV de entrada e insere os registros na estrutura de dados primária
int carregar_base(void *base, char *tipo_base, char *input_file, int limit, char *reader_name,
                  void *(*ler_item)(FILE *fp),
                  void (*pular_cabecalho)(FILE *fp),
                  int (*comparar_item)(void *item1, void *item2, char *campo));

// Callback invocada no percurso da busca: avalia o item contra a query e insere na estrutura de resultado
void processar_item(void *item, void *ctx_void);

// Percorre uma estrutura de dados e processa o item
void estrutura_percorrer(const char *tipo, void *estrutura, void (*funcao)(void *, void *), void *ctx);

// Percorre a estrutura de dados resultante e grava em um arquivo de texto os dados dos itens
int escrever_resultados(ContextoEscrita *ctx, void *result_structure, const char *result_type, const char *output_file);


// --- FUNÇÃO PRINCIPAL ---

int main(int argc, char *argv[]) {
    char *reader_name = NULL;
    char *input_file = NULL;
    char *base_type = NULL;
    char *result_type = NULL;
    char *query_file = NULL;
    char *output_file = NULL;
    int top_k = 0;
    int limit = 0;

    // Faz a leitura do que foi digitado pelo usuario
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--reader") == 0 && i + 1 < argc) reader_name = argv[++i];
        else if (strcmp(argv[i], "--input") == 0 && i + 1 < argc) input_file = argv[++i];
        else if (strcmp(argv[i], "--base") == 0 && i + 1 < argc) base_type = argv[++i];
        else if (strcmp(argv[i], "--result") == 0 && i + 1 < argc) result_type = argv[++i];
        else if (strcmp(argv[i], "--query") == 0 && i + 1 < argc) query_file = argv[++i];
        else if (strcmp(argv[i], "--output") == 0 && i + 1 < argc) output_file = argv[++i];
        else if (strcmp(argv[i], "--top-k") == 0 && i + 1 < argc) top_k = atoi(argv[++i]);
        else if (strcmp(argv[i], "--limit") == 0 && i + 1 < argc) limit = atoi(argv[++i]);
    }

    if (!reader_name || !input_file || !base_type || !result_type || !query_file || !output_file) {
        fprintf(stderr, "Erro: Parâmetros insuficientes.\n");
        return 1;
    }

    // Variaveis relacionadas a medicao de tempo
    clock_t inicio_tempo;
    double load_ms = 0.0, search_ms = 0.0, insert_ms = 0.0, write_ms = 0.0;
    int input_records = 0;
    int matched_records = 0;
    int output_records = 0;

    // Salva o cabecalho
    char cabecalho[2048] = "";
    FILE *f = fopen(input_file, "r");
    if (f) {
        if (fgets(cabecalho, sizeof(cabecalho), f))
            cabecalho[strcspn(cabecalho, "\r\n")] = '\0';
        fclose(f);
    }

    // Cria a estrutura base
    void *base_structure = criar_estrutura(base_type);
    if (!base_structure) return 1;

    // Declaracao das "funcoes coringa" relacionadas ao item e reader
    int (*comparar_item)(void *item1, void *item2, char *campo) = NULL;
    void (*apagar_item)(void**) = NULL;
    void (*imprimir_item_csv)(void*, FILE*) = NULL;
    void (*reader_pular_cabecalho)(FILE*) = NULL;
    void* (*reader_ler_item)(FILE *) = NULL;
    void (*extrair_valor_campo)(void *, const char *, char *, int) = NULL;
    void (*definir_similaridade) (void*,double);

    // Atribui as "funcoes coringa" dependendo do reader digitado
    if (strcasecmp(reader_name, "nasa") == 0) {
        comparar_item = (int (*)(void *, void *, char *)) item_nasa_comparar; 
        apagar_item = (void (*)(void**)) item_nasa_apagar;
        imprimir_item_csv = (void (*) (void*, FILE*)) item_nasa_imprimir_csv;
        reader_pular_cabecalho = (void (*)(FILE*)) reader_nasa_pular_cabecalho;
        reader_ler_item = (void *(*) (FILE*)) reader_nasa_ler_item;
        extrair_valor_campo = (void (*) (void*, const char*, char*, int)) extrair_valor_campo_item_nasa;
        definir_similaridade = (void (*) (void*,double)) item_set_calculated_similarity;
    } else if (strcasecmp(reader_name, "MEC") == 0) {
        comparar_item = (int (*)(void *, void *, char *)) item_mec_comparar; 
        apagar_item = (void (*)(void**)) item_mec_apagar;
        imprimir_item_csv = (void (*) (void*, FILE*)) item_mec_imprimir_csv;
        reader_pular_cabecalho = (void (*)(FILE*)) reader_mec_pular_cabecalho;
        reader_ler_item = (void *(*) (FILE*)) reader_mec_ler_item;
        extrair_valor_campo = (void (*) (void*, const char*, char*, int)) extrair_valor_campo_item_mec;
        definir_similaridade = (void (*) (void*,double)) item_mec_set_calculated_similarity;
    } else {
        fprintf(stderr, "Erro: Leitor invalido '%s'\n", reader_name);
        apagar_estutura(base_type, &base_structure, NULL);
        return 1;
    }

    // Calcula o tempo de carregamento da base da estrutura de dados inicial
    inicio_tempo = clock();
    input_records = carregar_base(base_structure, base_type, input_file, limit, reader_name, reader_ler_item, reader_pular_cabecalho, comparar_item);
    load_ms = ((double)(clock() - inicio_tempo)) * 1000.0 / CLOCKS_PER_SEC;

    // Cria a estrutura resultante
    void *result_structure = criar_estrutura(result_type);
    if (!result_structure) {
        apagar_estutura(base_type, &base_structure, apagar_item);
        return 1;
    }

    // Carrega a Query 
    QUERY *query = query_carregar(query_file);
    if (!query) {
        apagar_estutura(base_type, &base_structure, apagar_item);
        apagar_estutura(result_type, &result_structure, NULL);
        return 1;
    }

    // Contexto de Busca
    ContextoBusca ctx = {
        .query = query,
        .result_structure = result_structure,
        .result_type = result_type,
        .matched_records = &matched_records,
        .insert_ms = &insert_ms,
        .reader_name = reader_name,
        .extrair_valor_campo = extrair_valor_campo,
        .comparar_item = comparar_item,
        .definir_similaridade = definir_similaridade
    };

    inicio_tempo = clock();

    // Percorre a estrutura de base e insere na estrutura de resultado
    estrutura_percorrer(base_type, base_structure, processar_item, &ctx);
    
    // Calcula o tempo total de busca
    double tempo_total_busca = ((double)(clock() - inicio_tempo)) * 1000.0 / CLOCKS_PER_SEC;
    search_ms = tempo_total_busca - insert_ms; 
    if (search_ms < 0) search_ms = 0.0;

    // Instanciação do Contexto de Escrita 
    ContextoEscrita ctx_escrita = {
        .saida = NULL,
        .top_k = top_k,
        .registros_escritos = 0,
        .imprimir_item_csv = imprimir_item_csv,
        .cabecalho = cabecalho
    };

    // Escreve os resultados em um arquivo CSV e calcula o tempo de gravacao
    inicio_tempo = clock();
    output_records = escrever_resultados(&ctx_escrita, result_structure, result_type, output_file);
    write_ms = ((double)(clock() - inicio_tempo)) * 1000.0 / CLOCKS_PER_SEC;

    // Relatório de Saída
    printf("STATUS=OK\n");
    printf("INPUT_RECORDS=%d\n", input_records);
    printf("MATCHED_RECORDS=%d\n", matched_records);
    printf("OUTPUT_RECORDS=%d\n", output_records);
    printf("LOAD_MS=%.3f\n", load_ms);
    printf("SEARCH_MS=%.3f\n", search_ms);
    printf("RESULT_INSERT_MS=%.3f\n", insert_ms);
    printf("WRITE_MS=%.3f\n", write_ms);

    // Liberação de Memória
    query_destruir(&query);
    apagar_estutura(base_type, &base_structure, apagar_item);
    apagar_estutura(result_type, &result_structure, NULL);

    return 0;
}


// --- DEFINIÇÃO DAS FUNÇÕES ---

void gravar_item_csv(void *item, void *ctx_void) {
    ContextoEscrita *ctx = (ContextoEscrita *) ctx_void;

    if (ctx->top_k > 0 && ctx->registros_escritos >= ctx->top_k) {
        return;
    }

    ctx->imprimir_item_csv(item, ctx->saida);
    ctx->registros_escritos++;
}

void* criar_estrutura(char *tipo) {
    if (tipo == NULL) return NULL;
    if (strcmp(tipo, "pilha") == 0)        return pilha_criar();
    if (strcmp(tipo, "fila") == 0)         return fila_criar();
    if (strcmp(tipo, "lista_seq") == 0)    return lista_seq_criar();
    if (strcmp(tipo, "lista_enc") == 0)    return lista_enc_criar();
    if (strcmp(tipo, "lista_cabeca") == 0) return lista_cabeca_criar();
    if (strcmp(tipo, "lista_ord") == 0)    return lista_ord_criar();
    if (strcmp(tipo, "lista_gen") == 0)    return lista_gen_criar();
    if (strcmp(tipo, "lista_cruz") == 0)   return lista_cruz_criar();
    return NULL;
}

void apagar_estutura(char *tipo, void **estrutura, void liberar_item(void **item)) {
    if (tipo == NULL || estrutura == NULL || *estrutura == NULL) return;
    if (strcmp(tipo, "pilha") == 0)        { pilha_apagar((PILHA **)estrutura, liberar_item); return; }        
    if (strcmp(tipo, "fila") == 0)         { fila_apagar((FILA **)estrutura, liberar_item); return; }          
    if (strcmp(tipo, "lista_seq") == 0)    { lista_seq_apagar((LISTA_SEQ **)estrutura, liberar_item); return; }    
    if (strcmp(tipo, "lista_enc") == 0)    { lista_enc_apagar((LISTA_ENC **)estrutura, liberar_item); return; }      
    if (strcmp(tipo, "lista_cabeca") == 0) { lista_cabeca_apagar((LISTA_CABECA **)estrutura, liberar_item); return; }  
    if (strcmp(tipo, "lista_ord") == 0)    { lista_ord_apagar((LISTA_ORD **)estrutura, liberar_item); return; }      
    if (strcmp(tipo, "lista_gen") == 0)    { lista_gen_destruir((LISTA_GEN **)estrutura, liberar_item); return; }      
    if (strcmp(tipo, "lista_cruz") == 0)   { lista_cruz_apagar((LISTA_CRUZ **)estrutura, liberar_item); return; }    
}

int carregar_base(void *base, char *tipo_base, char *input_file, int limit, char *reader_name,
                  void *(*ler_item)(FILE *fp),
                  void (*pular_cabecalho)(FILE *fp),
                  int (*comparar_item)(void *item1, void *item2, char *campo)) {
    
    if (base == NULL || tipo_base == NULL || input_file == NULL || ler_item == NULL) return -1;

    FILE *fp = fopen(input_file, "r");
    if (fp == NULL) {
        fprintf(stderr, "Erro ao abrir o arquivo: %s\n", input_file);
        return -1;
    }

    if (pular_cabecalho != NULL) {
        pular_cabecalho(fp);
    }
    
    int registros_lidos = 0;
    bool is_mec = (reader_name != NULL && (strcasecmp(reader_name, "MEC") == 0));

    void *item = NULL;
    while ((limit <= 0 || registros_lidos < limit) && (item = ler_item(fp)) != NULL) {
        if (strcmp(tipo_base, "pilha") == 0) {
            pilha_empilhar((PILHA*)base, item);
        } 
        else if (strcmp(tipo_base, "fila") == 0) {
            fila_inserir((FILA*)base, item);
        } 
        else if (strcmp(tipo_base, "lista_seq") == 0) {
            lista_seq_inserir_inicio((LISTA_SEQ*)base, item);
        } 
        else if (strcmp(tipo_base, "lista_enc") == 0) {
            lista_enc_inserir_inicio((LISTA_ENC*)base, item);
        } 
        else if (strcmp(tipo_base, "lista_cabeca") == 0) {
            lista_cabeca_inserir_inicio((LISTA_CABECA*)base, item);
        } 
        else if (strcmp(tipo_base, "lista_ord") == 0) {
            char *padrao = (char *) (is_mec ? "codigo_ies" : "year"); 
            lista_ord_inserir((LISTA_ORD*)base, item, padrao, false, comparar_item);
        } 
        else if (strcmp(tipo_base, "lista_gen") == 0) {
            char *padrao1 = (char *) (is_mec ? "categoria_administrativa" : "threat_category");
            char *padrao2 = (char *) (is_mec ? "uf" : "year");
            lista_gen_inserir((LISTA_GEN*)base, item, padrao1, padrao2);
        } 
        else if (strcmp(tipo_base, "lista_cruz") == 0) {
            char *padrao1 = (char *) (is_mec ? "uf" : "year");
            char *padrao2 = (char *) (is_mec ? "regiao" : "month");
            lista_cruz_inserir((LISTA_CRUZ*)base, item, padrao1, padrao2);
        }

        registros_lidos++;
    }

    fclose(fp);
    return registros_lidos;
}

void processar_item(void *item, void *ctx_void) {
    ContextoBusca *ctx = (ContextoBusca*) ctx_void;
    if (ctx == NULL || item == NULL) return;

    bool is_mec = (ctx->reader_name != NULL && (strcasecmp(ctx->reader_name, "MEC") == 0));
    double sim = 0;

    if (query_avaliar_item(ctx->query, item, ctx->extrair_valor_campo,&sim)) {
        ctx->definir_similaridade(item, sim);
        (*(ctx->matched_records))++;

        clock_t inicio_insercao = clock();

        if (strcmp(ctx->result_type, "pilha") == 0) {
            pilha_empilhar((PILHA*)ctx->result_structure, item);
        } 
        else if (strcmp(ctx->result_type, "fila") == 0) {
            fila_inserir((FILA*)ctx->result_structure, item);
        } 
        else if (strcmp(ctx->result_type, "lista_seq") == 0) {
            lista_seq_inserir_inicio((LISTA_SEQ*)ctx->result_structure, item);
        } 
        else if (strcmp(ctx->result_type, "lista_enc") == 0) {
            lista_enc_inserir_inicio((LISTA_ENC*)ctx->result_structure, item);
        } 
        else if (strcmp(ctx->result_type, "lista_cabeca") == 0) {
            lista_cabeca_inserir_inicio((LISTA_CABECA*)ctx->result_structure, item);
        } 
        else if (strcmp(ctx->result_type, "lista_ord") == 0) {
            char *campo_ordem = (char *) query_obter_order_campo(ctx->query);
            char *padrao = (char *) (is_mec ? "codigo_ies" : "year");
            if (campo_ordem == NULL || campo_ordem[0] == '\0') campo_ordem = padrao; 
            lista_ord_inserir((LISTA_ORD*)ctx->result_structure, item, campo_ordem, query_order_desc(ctx->query), ctx->comparar_item);
        } 
        else if (strcmp(ctx->result_type, "lista_gen") == 0) {
            char *campo1 = (char *) query_obter_group_campo1(ctx->query);
            char *campo2 = (char *) query_obter_group_campo2(ctx->query);
            
            char *padrao1 = (char *) (is_mec ? "categoria_administrativa" : "threat_category");
            char *padrao2 = (char *) (is_mec ? "uf" : "year");

            if (campo1 == NULL || campo1[0] == '\0') campo1 = padrao1;
            if (campo2 == NULL || campo2[0] == '\0') campo2 = padrao2;

            char val1[128] = "";
            char val2[128] = "";

            if (ctx->extrair_valor_campo != NULL) {
                ctx->extrair_valor_campo(item, campo1, val1, sizeof(val1));
                ctx->extrair_valor_campo(item, campo2, val2, sizeof(val2));
            }

            lista_gen_inserir((LISTA_GEN*)ctx->result_structure, item, val1, val2);
        }
        else if (strcmp(ctx->result_type, "lista_cruz") == 0) {
            char *c1 = (char *) query_obter_cross_campo1(ctx->query);
            char *c2 = (char *) query_obter_cross_campo2(ctx->query);
            
            char *padrao1 = (char *) (is_mec ? "uf" : "year");
            char *padrao2 = (char *) (is_mec ? "regiao" : "month");

            if (c1 == NULL || c1[0] == '\0') c1 = padrao1;
            if (c2 == NULL || c2[0] == '\0') c2 = padrao2;

            char val1[128] = "";
            char val2[128] = "";
            
            if (ctx->extrair_valor_campo != NULL) {
                ctx->extrair_valor_campo(item, c1, val1, sizeof(val1));
                ctx->extrair_valor_campo(item, c2, val2, sizeof(val2));
            }

            lista_cruz_inserir((LISTA_CRUZ*)ctx->result_structure, item, val1, val2);
        }

        *(ctx->insert_ms) += ((double)(clock() - inicio_insercao)) * 1000.0 / CLOCKS_PER_SEC;
    }
}

void estrutura_percorrer(const char *tipo, void *estrutura, void (*funcao)(void *, void *), void *ctx) {
    if (tipo == NULL || estrutura == NULL || funcao == NULL) return;

    if (strcmp(tipo, "pilha") == 0)        pilha_percorrer((PILHA *)estrutura, funcao, ctx);
    else if (strcmp(tipo, "fila") == 0)         fila_percorrer((FILA *)estrutura, funcao, ctx);
    else if (strcmp(tipo, "lista_seq") == 0)    lista_seq_percorrer((LISTA_SEQ *)estrutura, funcao, ctx);
    else if (strcmp(tipo, "lista_enc") == 0)    lista_enc_percorrer((LISTA_ENC *)estrutura, funcao, ctx);
    else if (strcmp(tipo, "lista_cabeca") == 0) lista_cabeca_percorrer((LISTA_CABECA *)estrutura, funcao, ctx);
    else if (strcmp(tipo, "lista_ord") == 0)    lista_ord_percorrer((LISTA_ORD *)estrutura, funcao, ctx);
    else if (strcmp(tipo, "lista_gen") == 0)    lista_gen_percorrer((LISTA_GEN *)estrutura, funcao, ctx);
    else if (strcmp(tipo, "lista_cruz") == 0)   lista_cruz_percorrer((LISTA_CRUZ *)estrutura, funcao, ctx);
}

int escrever_resultados(ContextoEscrita *ctx, void *result_structure, const char *result_type, const char *output_file) {
    if (ctx == NULL || result_structure == NULL || result_type == NULL || output_file == NULL) {
        return 0;
    }

    FILE *fp_out = fopen(output_file, "w");
    if (fp_out == NULL) {
        fprintf(stderr, "Erro ao abrir o arquivo de saída: %s\n", output_file);
        return 0;
    }

    fprintf(fp_out, "%s\n", ctx->cabecalho);
    ctx->saida = fp_out;
    ctx->registros_escritos = 0;

    estrutura_percorrer(result_type, result_structure, gravar_item_csv, ctx);

    fclose(fp_out);
    return ctx->registros_escritos;
}