#include "lista_ord.h"
#include <stdlib.h>


#define CAPACIDADE_INICIAL 1024

struct lista {
    void **itens;
    int size;
    int capacidade;
};

bool lista_vazia_ord(LISTA_ORD *lista){
    return (lista == NULL || lista->size == 0);
}

int lista_tamanho_ord(LISTA_ORD *lista){
    if(lista == NULL) return -1;
    return lista->size;
}

LISTA_ORD *lista_ord_criar(void){
    LISTA_ORD *l = (LISTA_ORD *) malloc(sizeof(LISTA_ORD));
    if(l == NULL) return NULL;

    l->itens = (void **) malloc(CAPACIDADE_INICIAL * sizeof(void *));
    if(l->itens == NULL){
        free(l);
        return NULL;
    }
    l->capacidade = CAPACIDADE_INICIAL;
    l->size = 0;
    return l;
}

bool lista_ord_inserir(LISTA_ORD *l, void *item, char *campo, bool desc,
                       int (*item_comparar_func)(void *, void *, char *)){
    if(l == NULL || item == NULL || item_comparar_func == NULL) return false;

    // Expande o vetor (dobra a capacidade) quando está cheio
    if(l->size == l->capacidade){
        void **novo = (void **) realloc(l->itens, 2 * l->capacidade * sizeof(void *));
        if(novo == NULL) return false;
        l->itens = novo;
        l->capacidade *= 2;
    }

    // Busca binária: acha a posição onde o item deve ser inserido
    int ini = 0, fim = l->size;
    while(ini < fim){
        int meio = (ini + fim) / 2;
        int c = item_comparar_func(l->itens[meio], item, campo);
        if(desc) c = -c;

        if(c > 0) fim = meio;       
        else ini = meio + 1;        
    }

    
    for(int i = l->size; i > ini; i--){
        l->itens[i] = l->itens[i - 1];
    }
    
    l->itens[ini] = item;
    l->size++;
    return true;
}

void lista_ord_apagar(LISTA_ORD **lista, void (*liberar_item)(void **item)){
    if(lista == NULL || *lista == NULL) return;

    for(int i = 0; i < (*lista)->size; i++){
        void *item = (*lista)->itens[i];
        if(liberar_item != NULL && item != NULL) liberar_item(&item);
    }
    free((*lista)->itens);
    free(*lista);
    *lista = NULL;
}

void lista_ord_percorrer(LISTA_ORD *l, void (*processar)(void *item, void *contexto), void *contexto){
    if(l == NULL || processar == NULL) return;
    for(int i = 0; i < l->size; i++)
        processar(l->itens[i], contexto);
}